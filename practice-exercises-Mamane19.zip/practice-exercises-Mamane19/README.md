Exercise 1


Write a program that will prompt the user to input ten integer values. The program should then display the smallest and greatest of those values. It should also display the value that occurs the most.  [2 pts]

Exercise 2

Write a C program that calculates the factorial of a given number. [2 pt]

What is factorial?

Factorial of a number n is the product of all positive integers less than or equal to n.

For Example:

Factorial 5 is:

5! = 120 [That is equivalent to 5*4*3*2*1 =120




Exercise 3

Write a program in C to add numbers using call by reference.  [2 points]

(This means that you write a function to add two numbers. The arguments of your function should be pointers to the numbers and not values)


Exercise 4

Write a program in C to find the maximum number between two numbers using a pointer. [2 points]


Exercise 5

Write a program in C to store n elements in an array and print the elements using a pointer. [2 points]


Exercise 6

Write a program in C to print all permutations of a given string using pointers.[2 points]


Exercise 7  [5 points]

Write a program in C which has:  [Total : 5 points]

structure to store the name, account number, and balance of customers (more than 10) and store their information. [1 point]
a function to print the names of all the customers having a balance of less than $200. [2 points]
a function to add $100 in the balance of all the customers having more than $1000 in their balance and then print the incremented value of their balance. [2 points]

Exercise 8


Write a program in C  [Total : 3 points]

to count the number of words and characters in a file [1.5]
to replace a specific line with another text [1.5]
For problem b, assume that the content of the file test.txt is:                                                                       

test line 1                                                                                                  

test line 2                                                                                                  

test line 3                                                                                                  

test line 4                                                                                                  


Test Data :

Input the file name to be opened: test.txt

Input the content of the new line: Yes, I am the new text instead of test line 2

Input the line no you want to replace: 2


Expected Output  :


test line 1                                                                                                  

Yes, I am the new text instead of test line 2                                                                                                

test line 3                                                                                                  

test line 4                                                                                                  



Exercise 9  


Write a program to create one parent with three children using fork() function where each process find its PID. [use getpid() for PID].    [3 points]


Exercise 10


Write a program to create a child process and sent a string from child to parent and display it.[2 points]